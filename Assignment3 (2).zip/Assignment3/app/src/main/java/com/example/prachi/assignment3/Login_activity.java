package com.example.prachi.assignment3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login_activity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
    }
    public void login_onclick(View view){
        SharedPreferences sp = getSharedPreferences("Userdata", Context.MODE_PRIVATE);
        SharedPreferences.Editor data = sp.edit();
        data.putString("Uname",username.getText().toString() );
        data.putString("Pass", password.getText().toString());
        data.apply();
        Toast.makeText(this, "Saved", Toast.LENGTH_LONG).show();
        Intent i = new Intent(this,menu.class);
        startActivity(i);
    }
    public void last_login(View view){
        SharedPreferences sp = getSharedPreferences("Userdata", Context.MODE_PRIVATE);
        String uname = sp.getString("Uname", "");
        String pass = sp.getString("pass","");
        username.setText(uname);
        password.setText(pass);
    }

}
