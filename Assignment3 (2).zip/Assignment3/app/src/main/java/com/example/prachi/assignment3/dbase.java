package com.example.prachi.assignment3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

public class dbase extends SQLiteOpenHelper {

    private TextView starter;
    private TextView maincourse;
    private TextView beverage;
    private static final int db_version = 1;
    private static final String db_name= "";
    private static final String tablename = "order";
    private static final String  col1 = "starter";
    private static final String  col2 = "maincourse";
    private static final String  col3 = "beverage";

    public dbase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, db_name, factory, db_version);
    }

//    public dbase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
//        super(context, name, factory, version, errorHandler);
//    }

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_dbase);
//        beverage = (TextView) findViewById(R.id.beverage);
//        starter = (TextView) findViewById(R.id.starter);
//        maincourse = (TextView) findViewById(R.id.maincourse);
//    }
    public void viewdb(){

    }
    public void deldb(){

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
