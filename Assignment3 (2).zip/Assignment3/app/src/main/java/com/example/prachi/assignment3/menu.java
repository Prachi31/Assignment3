package com.example.prachi.assignment3;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;


public class menu extends AppCompatActivity {


    private EditText maincourse;
    private EditText starter;
    private EditText beverage;
    Context context = this;
    String fname ="data.txt";
    public String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Assignment3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        beverage = (EditText) findViewById(R.id.beverage);
        starter = (EditText) findViewById(R.id.starter);
        maincourse = (EditText) findViewById(R.id.maincourse);
        //File file = new File(context.getFilesDir(), fname);
        File ext_dir = new File(path);
        ext_dir.mkdirs();
    }

    public void database_func(View view){

        Intent i = new Intent(this, dbase.class);
        i.putExtra(starter.getText().toString(),"starter");
        i.putExtra(maincourse.getText().toString(),"maincourse");
        i.putExtra(beverage.getText().toString(),"beverage");
        startActivity(i);
    }

    public void internal_func(View view){

        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(fname, Context.MODE_PRIVATE);
            outputStream.write(starter.getText().toString().getBytes() );
            outputStream.write(maincourse.getText().toString().getBytes() );
            outputStream.write(beverage.getText().toString().getBytes() );
            outputStream.write("\n".getBytes() );
            outputStream.close();
            Toast.makeText(getApplicationContext(),"file saved",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isExternalStorageWritable(){
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }

    public void external_func(View view){
        File ext_file = new File(path + "/order.txt");
        boolean write = isExternalStorageWritable();
        boolean read = isExternalStorageReadable();
        String data[] = {starter.getText().toString(),maincourse.getText().toString(),",",beverage.getText().toString(),"\n" };
        FileOutputStream output = null;
        if(write){
            try{
                output = new FileOutputStream(ext_file);
            }
            catch(FileNotFoundException e){
                e.printStackTrace();
            }
            try{
                try{
                    output.write(starter.getText().toString().getBytes());
                    output.write(maincourse.getText().toString().getBytes());
                    output.write(beverage.getText().toString().getBytes());
                }
                catch (IOException e) {e.printStackTrace();}
            }
            finally{
                try{
                    output.close();
                }
                catch (IOException e) {e.printStackTrace();}
            }
        }
        Toast.makeText(getApplicationContext(),"Saved to" + path , Toast.LENGTH_LONG).show();
    }
}
